/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package videoindexing;

import com.xuggle.mediatool.IMediaReader;
import com.xuggle.mediatool.MediaListenerAdapter;
import com.xuggle.mediatool.ToolFactory;
import com.xuggle.mediatool.event.IVideoPictureEvent;
import com.xuggle.xuggler.Global;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.TableModel;
import videoindexing.tfidf.TfIdfMain;
import videoindexing.tfidf.UploadVideo;

public class VideoIndexingUI extends JPanel
{
   String[] columns = {"Video Name", "TFIDF Rank"};
   String[][] resultObj= new String[5][5];
   SearchResultPojo[] dataObj=new SearchResultPojo[10]; 
   JPanel userPanel= new JPanel();
   JPanel loginPanel= new JPanel();
   JPanel passPanel= new JPanel();
   private ImageIcon ic= new ImageIcon("D:\\piyush code\\videoIndexing\\images\\Video1.jpg");        
   JLabel backLabel= new JLabel(ic);
   JLabel uploadLabel= new JLabel("                          Video Uploaded Successfully !!!!!!             ");
   JTable table;
    JScrollPane scrollPane = new JScrollPane(table);
    JLabel lblHeading = new JLabel("Search Results");
    JLabel usernameLabel= new JLabel("Username");
    JLabel passwordLabel= new JLabel("Password");
    JTextField userText= new JTextField();
    JTextField passText= new JTextField();
    JLabel browseLabel= new JLabel("Please select a video file....");
    JButton button = new JButton("Select  File");
    JButton search = new JButton("Search Video");
    JButton login = new JButton("Login");
    JButton open = new JButton("Open Video");
    JButton back= new JButton("Back to Login Page");
    JButton upload= new JButton("Upload Video");
    JTextField queryText= new JTextField();
    static List<String> urlList = new ArrayList<String>();
    JLabel errorMsg= new JLabel("************Invalid login.. Please try again..************");    
    public static final double SECONDS_BETWEEN_FRAMES = 10;
    File selectedFile;
    private static String inputFilename = "c:/Users/Sony/Desktop/New Folder/abcd.mp4";
    private static String onlyFileName= "";
    private static final String outputFilePrefix = "c:/snapshots/mysnapshot";
     
    // The video stream index, used to ensure we display frames from one and
    // only one video stream from the media container.
    private static int mVideoStreamIndex = -1;
    
    // Time of last frame write
    private static long mLastPtsWrite = Global.NO_PTS;
static final JEditorPane ResultsArea = new JEditorPane();    
    public static final long MICRO_SECONDS_BETWEEN_FRAMES = 
        (long)(Global.DEFAULT_PTS_PER_SECOND * SECONDS_BETWEEN_FRAMES);

    //-----------------------------------------------------------------
   //  Constructor: Sets up the GUI.
   //-----------------------------------------------------------------
   public VideoIndexingUI ()
   {
 
       

     uploadLabel.setVisible(false);
ResultsArea.setEditorKit(JEditorPane.createEditorKitForContentType("text/html"));
ResultsArea.setEditable(false);  
     
     queryText.setColumns(30);
     userText.setColumns(19);
     passText.setColumns(19);
     browseLabel.setForeground(Color.BLUE);
    usernameLabel.setForeground(Color.BLUE);
    passwordLabel.setForeground(Color.BLUE);
    errorMsg.setForeground(Color.red);
    browseLabel.setVisible(false);
    button.setVisible(false);
    upload.setVisible(false);
    queryText.setVisible(false);
    search.setVisible(false);
    errorMsg.setVisible(false);
    back.setVisible(false);
    login.addActionListener(new LoginListner());
    open.addActionListener(new OpenVideoListner());
    back.addActionListener(new BackListner());
    search.addActionListener(new SearchListner());
    upload.addActionListener(new UploadListner());
//    table.setFillsViewportHeight(true);
    lblHeading.setFont(new Font("Arial",Font.TRUETYPE_FONT,24));
    lblHeading.setVisible(false);
//    scrollPane.setVisible(false);
  //  table.setVisible(false);
    open.setVisible(false);
    ResultsArea.setVisible(false);
    //add(lblHeading,BorderLayout.PAGE_START);
    //add(ResultsArea);    
   // add(scrollPane,BorderLayout.CENTER);
    add(errorMsg);
    userPanel.add(usernameLabel);
    userPanel.add(userText);
    userPanel.setLocation(0, 0);
//    loginPanel.add(userPanel);
    passPanel.add(passwordLabel);
    passPanel.add(passText);
    passPanel.setBounds(50, 50, 50, 50);
 //   loginPanel.add(passPanel);
    loginPanel.setAlignmentX(50);
    
    
   // add(loginPanel);
    add(userPanel);
    add(passPanel);
    add(login);
    
    userPanel.add(browseLabel);
    userPanel.add(button);
  //  add(upload);
    userPanel.add(queryText);
    passPanel.add(search); 
    passPanel.add(back);
    add(uploadLabel);
    //userPanel.add(lblHeading);
    add(ResultsArea);
    add(open);
    
    add(backLabel);
    setPreferredSize(new Dimension(360, 430));
    setBackground(Color.white);
    
//    System.out.println("select row is: "+table.getSelectedRow());
    
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent ae) {
          uploadLabel.setVisible(false);
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(null);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
          selectedFile = fileChooser.getSelectedFile();
          System.out.println(selectedFile.getAbsolutePath());
          inputFilename=selectedFile.getAbsolutePath();
          onlyFileName=selectedFile.getName();
          IMediaReader mediaReader = ToolFactory.makeReader(inputFilename);

        // stipulate that we want BufferedImages created in BGR 24bit color space
        mediaReader.setBufferedImageTypeToGenerate(BufferedImage.TYPE_3BYTE_BGR);
        
        mediaReader.addListener(new VideoIndexingUI.ImageSnapListener());

        // read out the contents of the media file and
        // dispatch events to the attached listener
        while (mediaReader.readPacket() == null);
        }
        
         UploadVideo obj= new UploadVideo(selectedFile, onlyFileName);
         uploadLabel.setVisible(true);
      }
    }); 
   }

   //*****************************************************************
   //  Represents a listener for button push (action) events.
   //*****************************************************************
   
      //--------------------------------------------------------------
      //  Updates the counter and label when the button is pushed.
      //--------------------------------------------------------------
     
       private static class ImageSnapListener extends MediaListenerAdapter {

        public void onVideoPicture(IVideoPictureEvent event) {

            if (event.getStreamIndex() != mVideoStreamIndex) {
                // if the selected video stream id is not yet set, go ahead an
                // select this lucky video stream
                if (mVideoStreamIndex == -1)
                    mVideoStreamIndex = event.getStreamIndex();
                // no need to show frames from this video stream
                else
                    return;
            }

            // if uninitialized, back date mLastPtsWrite to get the very first frame
            if (mLastPtsWrite == Global.NO_PTS)
                mLastPtsWrite = event.getTimeStamp() - MICRO_SECONDS_BETWEEN_FRAMES;

            // if it's time to write the next frame
            if (event.getTimeStamp() - mLastPtsWrite >= 
                    MICRO_SECONDS_BETWEEN_FRAMES) {
                                
                String outputFilename = dumpImageToFile(event.getImage());

                // indicate file written
                double seconds = ((double) event.getTimeStamp()) / 
                    Global.DEFAULT_PTS_PER_SECOND;
                System.out.printf(
                        "at elapsed time of %6.3f seconds wrote: %s\n",
                        seconds, outputFilename);
            ExtractImage obj= new ExtractImage();
            System.out.println("inputFilename: "+inputFilename);
            System.out.println("onlyFileName: "+onlyFileName);
            obj.fetchText(onlyFileName, outputFilename);
                // update last write time
                mLastPtsWrite += MICRO_SECONDS_BETWEEN_FRAMES;
            }

        }
        
        private String dumpImageToFile(BufferedImage image) {
            try {
                String outputFilename = outputFilePrefix + 
                     System.currentTimeMillis() + ".png";
                ImageIO.write(image, "png", new File(outputFilename));
                return outputFilename;
            } 
            catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

    }

   private class LoginListner implements ActionListener{
       
       public void actionPerformed(ActionEvent event) {
           
           
           
           if(userText.getText().equalsIgnoreCase("faculty") && passText.getText().equalsIgnoreCase("faculty")){
    usernameLabel.setVisible(false);
    userText.setVisible(false);
    passwordLabel.setVisible(false);
    passText.setVisible(false);
    login.setVisible(false);
    browseLabel.setVisible(true);
    button.setVisible(true);
    upload.setVisible(true);
    queryText.setVisible(false);
    search.setVisible(false);
    errorMsg.setVisible(false);
    back.setVisible(true);
    ResultsArea.setVisible(false);
           }
           else if(userText.getText().equalsIgnoreCase("student") && passText.getText().equalsIgnoreCase("student")){
    usernameLabel.setVisible(false);
    userText.setVisible(false);
    passwordLabel.setVisible(false);
    passText.setVisible(false);
    login.setVisible(false);
    browseLabel.setVisible(false);
    button.setVisible(false);
    upload.setVisible(false);
    queryText.setVisible(true);
    search.setVisible(true);
    errorMsg.setVisible(false);
    //ResultsArea.setVisible(true);
    back.setVisible(true);
           }       
           else{
               userText.setText("");
               passText.setText("");
               errorMsg.setVisible(true);
               back.setVisible(false);
           }
       }
   }
   
    private class OpenVideoListner implements ActionListener{
       
       public void actionPerformed(ActionEvent event) {
           
           
         System.out.println("table.getSelectedRow(): "+table.getSelectedRow()); 
          if(-1!=table.getSelectedRow()){
               try {  
                   Desktop.getDesktop().open(new File("C:\\Users\\Sony\\Videos"));
               } catch (IOException ex) {
                   Logger.getLogger(VideoIndexingUI.class.getName()).log(Level.SEVERE, null, ex);
               }
          }
       }
   }
   
    private class UploadListner implements ActionListener{
    @SuppressWarnings("empty-statement")
        public void actionPerformed(ActionEvent event){
        
        UploadVideo obj= new UploadVideo(selectedFile, onlyFileName);
    }
    }
    
    private class SearchListner implements ActionListener{
        @SuppressWarnings("empty-statement")
        public void actionPerformed(ActionEvent event){
            try {
//       if(null!=table){
//       remove(table);         
//       remove(scrollPane);
//       }
//       open.setVisible(true);
//       scrollPane.setVisible(true);
       
              //  Find objFind= new Find();
                TfIdfMain tfidfObj= new TfIdfMain();
              // dataObj= objFind.searchVideo(queryText.getText());
               urlList= tfidfObj.searchQuery(queryText.getText());
            StringBuilder resultBuil = new StringBuilder();
List<String>  stopWordsSet= new ArrayList<String>();
stopWordsSet.add("the");
stopWordsSet.add("is");
stopWordsSet.add("a");
stopWordsSet.add("are");

            for (String s : queryText.getText().split("\\b")) {
    if (!stopWordsSet.contains(s)) resultBuil.append(s);
}
 System.out.println("new string: "+ resultBuil);
            // System.out.println("dataObj[0]: "+dataObj[0].getVideoName());
               
//String pathVideo="C:\\Users\\Sony\\Videos\\";
String pathVideo="file:\\\\C:\\Users\\Sony\\Videos\\";
StringBuilder sb = new StringBuilder();
for (String s : urlList) {
    sb.append("<br><a href=").append(pathVideo).append(">").append(s).append("</a>\n");
}

ResultsArea.setText(sb.toString());
ResultsArea.setVisible(true);
//               for(int i=0; i<5;i++){
//               resultObj[i][0]=dataObj[i].getVideoName();
//               resultObj[i][1]=dataObj[i].getWordCount();
//               resultObj[i][2]=dataObj[i].getUrl();
//               }
    
               // if(null==table){
  //             table = new JTable(resultObj, columns);
              // }
                
//                table.repaint();
//                table.setVisible(true);
//                table.setFillsViewportHeight(true);
//                scrollPane = new JScrollPane(table);
//                add(scrollPane);
//
                lblHeading.setVisible(true);
//                scrollPane.setVisible(true);
            } catch (Exception ex) {
                Logger.getLogger(VideoIndexingUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
  private class BackListner implements ActionListener {
      public void actionPerformed(ActionEvent event){
          
          usernameLabel.setVisible(true);
          userText.setText("");
          userText.setVisible(true);
          passwordLabel.setVisible(true);
          passText.setText("");
          passText.setVisible(true);
          login.setVisible(true);
          lblHeading.setVisible(false);
          browseLabel.setVisible(false);
          button.setVisible(false);
          queryText.setVisible(false);
          search.setVisible(false);
          errorMsg.setVisible(false);
          back.setVisible(false);
//          table.setVisible(false);
//          scrollPane.setVisible(false);
          ResultsArea.setVisible(false);
//          remove(table);
//          remove(scrollPane);
          uploadLabel.setVisible(false);
          open.setVisible(false);
          
      }
  }
}

